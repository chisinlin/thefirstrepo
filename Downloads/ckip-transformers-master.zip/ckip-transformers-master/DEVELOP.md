# Release TODO

- change version number
- make sure requirements.txt and test/requirements.txt matches setup.py.

- > > make clean
- > > make lint
- > > make doc
- > > make tox
- > > make tox-report

- merge to master branch
- > > make clean
- > > make upload
