import pygame, random, sys
pygame.init()
pygame.mixer.init()

import sys, os

def resource_path(relative_path):
    """ 取得打包後的檔案路徑 """
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

pygame.mixer.music.load(resource_path("333.mp3"))  # 遊戲開始音樂
pygame.mixer.music.play(-1)  # -1 = 循環播放
boss_music_played = False    # 紀錄是否切換過 BGM
# === 基本設定 ===
WIDTH, HEIGHT = 480, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("1945")
clock, font = pygame.time.Clock(), pygame.font.SysFont(None, 30)

# === 載入圖片 ===
bg_img = pygame.image.load(resource_path("bg.png")).convert()
start_bg_img = pygame.image.load(resource_path("start_bg.png")).convert()
victory_bg_img = pygame.image.load(resource_path("victory_bg.png")).convert()
defeat_bg_img = pygame.image.load(resource_path("defeat_bg.png")).convert()
player_img = pygame.transform.scale(pygame.image.load(resource_path("player.png")).convert_alpha(), (60, 100))
enemy_img = pygame.transform.scale(pygame.image.load(resource_path("enemy.png")).convert_alpha(), (60, 60))
mgi_img = pygame.transform.scale(pygame.image.load(resource_path("mgi.png")).convert_alpha(), (40, 40))
bi_img = pygame.transform.scale(pygame.image.load(resource_path("bi.png")).convert_alpha(), (42, 60))
shield_img = pygame.transform.scale(pygame.image.load(resource_path("shield.png")).convert_alpha(), (80, 80))
heal_img = pygame.transform.scale(pygame.image.load(resource_path("heal.png")).convert_alpha(), (50, 50))
bullet_power_img = pygame.transform.scale(pygame.image.load(resource_path("b.png")).convert_alpha(), (12, 24))
boss_img = pygame.transform.scale(pygame.image.load(resource_path("boss.png")).convert_alpha(), (600, 600))
boss_bullet_img = pygame.transform.scale(pygame.image.load(resource_path("boss_bullet.png")).convert_alpha(), (40, 60))

# === 爆炸動畫 ===
boom_sheet = pygame.image.load(resource_path("boom.png")).convert_alpha()
bw, bh = boom_sheet.get_width() // 2, boom_sheet.get_height() // 2
explosion_frames = [pygame.transform.scale(boom_sheet.subsurface((x*bw, y*bh, bw, bh)), (bw//2, bh//2)) for y in range(2) for x in range(2)]
# Boss 爆炸
boss_boom_sheet = pygame.image.load(resource_path("boom_boss.png")).convert_alpha()
bb_w, bb_h = boss_boom_sheet.get_width() // 2, boss_boom_sheet.get_height() // 3
boss_explosion_frames = [
    pygame.transform.scale(boss_boom_sheet.subsurface((x * bb_w, y * bb_h, bb_w, bb_h)), (300, 300))
    for y in range(3) for x in range(2)
]
# 大招動畫
mg_sheet = pygame.image.load(resource_path("mg.png")).convert_alpha()
fw, fh = mg_sheet.get_width() // 4, mg_sheet.get_height() // 2
mg_frames = [pygame.transform.scale(mg_sheet.subsurface((i%4*fw, i//4*fh, fw, fh)), (600, 1200)) for i in range(8)]

# === 遊戲狀態 ===
game_state = "start"  # start / playing / boss_explode / victory
score, player_hp, max_hp, player_smooth_hp = 0, 100, 100, 100
bg_y1, bg_y2, bg_speed = 0, -HEIGHT, 2
player_rect = pygame.Rect(WIDTH//2 - 30, HEIGHT - 80, 60, 100)
bullets, enemies, enemy_bullets, explosions, specials, boss_explosions = [], [], [], [], [], []
mg_items, b_items, s_items, h_items = [], [], [], []
bullet_speed, bullet_cd, bullet_interval = 7, 0, 10
enemy_bullet_cd, enemy_bullet_interval = 0, 2500
spawn_timer, timers = 0, {"mg":0,"b":0,"s":0,"h":0}
special_count, special_speed = 0, 1
power_mode, power_time = False, 0
shield_mode, shield_time = False, 0
enemy_spawn_interval = 1000
enemy_hp_base = 50
boss_spawned, boss, boss_bullet_cd = False, None, 0
boss_flash_timer, boss_dead = 0, False
screen_shake = 0
title_font = pygame.font.SysFont("bahnschrift", 80, bold=True)  # 開始/勝利大標題
sub_font = pygame.font.SysFont("arial", 36, bold=True)     # 副標題

# === 函式 ===
def render_with_outline(text, font, text_color, outline_color, outline_width):
    base = font.render(text, True, text_color)
    size = (base.get_width() + outline_width*2, base.get_height() + outline_width*2)
    img = pygame.Surface(size, pygame.SRCALPHA)
    for dx in range(-outline_width, outline_width+1):
        for dy in range(-outline_width, outline_width+1):
            if dx*dx + dy*dy <= outline_width*outline_width:
                img.blit(font.render(text, True, outline_color), (dx+outline_width, dy+outline_width))
    img.blit(base, (outline_width, outline_width))
    return img

def spawn_item(lst, img, interval, key, amount=1, y=-40):
    timers[key]+=dt
    if timers[key] > interval:
        for _ in range(amount):
            lst.append(img.get_rect(center=(random.randint(30, WIDTH-30), y)))
        timers[key] = 0

def draw_bar(x, y, w, h, ratio, color):
    pygame.draw.rect(screen, (255,255,255), (x,y,w,h))
    pygame.draw.rect(screen, color, (x,y,w*ratio,h))
    pygame.draw.rect(screen, (0,0,0), (x,y,w,h),2)

def draw_slanted_bar(x, y, w, h, ratio, smooth_ratio):
    def clamp(val): return max(0, min(255, int(val)))
    display_ratio = max(0.0, min(1.0, smooth_ratio))
    if display_ratio > 0.5:
        r = clamp(255 * (1 - display_ratio) * 2)
        g = 255
    else:
        r = 255
        g = clamp(255 * display_ratio * 2)
    color = (r, g, 0)
    offset = 6
    base_points = [(x+offset, y), (x+w+offset, y), (x+w-offset, y+h), (x-offset, y+h)]
    fill_w = int(w * display_ratio)
    bar_points = [(x+offset, y), (x+fill_w+offset, y), (x+fill_w-offset, y+h), (x-offset, y+h)]
    pygame.draw.polygon(screen, (255,255,255), base_points)
    pygame.draw.polygon(screen, color, bar_points)
    pygame.draw.polygon(screen, (0,0,0), base_points, 2)

def draw_flash(rect, color):
    surf = pygame.Surface((rect.width+20, rect.height+20), pygame.SRCALPHA)
    pygame.draw.ellipse(surf, color, surf.get_rect()); screen.blit(surf, (rect.x-10, rect.y-10))

def draw_playing():  # 把原本的繪圖搬進來
    screen.blit(player_img, player_rect.move(shake_x, shake_y))
    if shield_mode: draw_flash(player_rect,(0,100,255,120))
    if power_mode: draw_flash(player_rect,(255,50,0,120))
    for b in bullets: screen.blit(bullet_power_img,b["rect"]) if b["powered"] else pygame.draw.rect(screen,(255,255,0),b["rect"])
    for eb in enemy_bullets:
        if isinstance(eb, dict): screen.blit(boss_bullet_img, eb["rect"])
        else: pygame.draw.rect(screen, (150, 0, 0), eb)
    for en in enemies:
        screen.blit(enemy_img, en["rect"])
        draw_slanted_bar(en["rect"].x, en["rect"].y - 8, en["rect"].width, 6, en["hp"]/en["max_hp"], en["smooth_hp"]/en["max_hp"])
    if boss:
        if boss_dead:
            # 清屏只畫背景 & 玩家 & 閃爍 Boss
            screen.blit(bg_img, (0,0))
            screen.blit(player_img, player_rect)
            if pygame.time.get_ticks() // 100 % 2 == 0:
                white_boss = boss_img.copy()
                white_boss.fill((255,255,255,100), None, pygame.BLEND_RGBA_ADD)
                screen.blit(white_boss, boss["rect"])
            else:
                screen.blit(boss_img, boss["rect"])
            return  # 直接跳出，不畫後面的血條/敵人/UI
        else:
            screen.blit(boss_img, boss["rect"].move(shake_x, shake_y))
            draw_slanted_bar(20, 20, WIDTH - 40, 20, boss["hp"]/boss["max_hp"], boss["smooth_hp"]/boss["max_hp"])
    for ex in explosions: screen.blit(explosion_frames[ex[1]],ex[0])
    for be in boss_explosions:
        img = pygame.transform.scale(boss_explosion_frames[be["frame"]], (500, 500))
        rect = img.get_rect(center=(be["rect"].centerx, be["rect"].centery + 100))
        screen.blit(img, rect.move(shake_x, shake_y))
    for sp in specials: screen.blit(mg_frames[sp["frame"]],sp["rect"])
    for lst,img in [(mg_items,mgi_img),(b_items,bi_img),(s_items,shield_img),(h_items,heal_img)]:
        [screen.blit(img,i) for i in lst]
    if power_mode: draw_bar(20,HEIGHT-90,200,10,power_time/10000,(255,50,0))
    if shield_mode: draw_bar(20,HEIGHT-110,200,10,shield_time/6000,(0,100,255))
    draw_slanted_bar(20, HEIGHT - 40, 200, 16, player_hp/max_hp, player_smooth_hp/max_hp)
    screen.blit(font.render(f"super bullet(Key_M): {special_count}",True,(255,255,0)),(20,HEIGHT-70))
    screen.blit(font.render(f"Score: {score}",True,(255,255,255)),(20,20))

# === 遊戲迴圈 ===
running = True
while running:
    dt = clock.tick(60)
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            running = False
        if e.type == pygame.KEYDOWN:
            if game_state == "start":
                game_state = "playing"
            elif game_state in ["victory", "defeat"]:
                running = False  # 按任意鍵退出
            elif e.key == pygame.K_m and special_count > 0 and game_state == "playing":
                special_count -= 1
                specials.append({"rect": mg_frames[0].get_rect(center=(player_rect.centerx, player_rect.top-100)), "frame":0, "timer":0})

    # === 遊戲主邏輯（只有 playing 狀態才跑）===
    if game_state == "playing":
        # 玩家移動
        mx,my = pygame.mouse.get_pos()
        player_rect.x, player_rect.y = max(0, min(mx-30, WIDTH-60)), max(0, min(my-50, HEIGHT-100))
        # 發射子彈
        if bullet_cd<=0:
            bullets += [{"rect":pygame.Rect(player_rect.centerx-3, player_rect.top-10, 12 if power_mode else 6, 24 if power_mode else 12), "powered":power_mode, "hit_targets": set()}]
            if power_mode:
                bullets += [
                    {"rect": pygame.Rect(player_rect.centerx - 18, player_rect.top, 12, 24), "powered": True, "hit_targets": set()},
                    {"rect": pygame.Rect(player_rect.centerx + 12, player_rect.top, 12, 24), "powered": True, "hit_targets": set()}
                ]
            bullet_cd=bullet_interval
        else: bullet_cd-=1
        for b in bullets[:]:
            b["rect"].y -= bullet_speed
            if b["rect"].bottom<0: bullets.remove(b)
        # 敵人子彈
        now = pygame.time.get_ticks()
        if now-enemy_bullet_cd>enemy_bullet_interval:
            enemy_bullets += [pygame.Rect(en["rect"].centerx-3, en["rect"].bottom, 6,12) for en in enemies]
            enemy_bullet_cd = now
        # 敵人生成
        spawn_timer+=dt
        if spawn_timer > enemy_spawn_interval:
            enemies.append({"rect": enemy_img.get_rect(center=(random.randint(30, WIDTH - 30), -40)), "hp": enemy_hp_base, "max_hp": enemy_hp_base, "smooth_hp": enemy_hp_base})
            spawn_timer = 0
        for en in enemies[:]:
            en["rect"].y+=3
            if en["rect"].top>HEIGHT: player_hp-=10; enemies.remove(en); continue
            if en["rect"].colliderect(player_rect): 
                if not shield_mode: player_hp-=20
                enemies.remove(en)
        # Boss
        if score >= 250 and not boss_spawned:
            boss_spawned = True
            boss = {"rect": boss_img.get_rect(center=(WIDTH//2, -100)),"hp": 5000, "max_hp": 5000, "smooth_hp": 5000,"speed": 2,"dir": 1}
            if not boss_music_played:  # 只切換一次
                pygame.mixer.music.load(resource_path("444.mp3"))
                pygame.mixer.music.play(-1)
                boss_music_played = True
        if boss:
            if boss["rect"].top < -300: boss["rect"].y += 2
            else:
                boss["rect"].x += boss["speed"] * boss["dir"]
                if boss["rect"].left <= 0 or boss["rect"].right >= WIDTH: boss["dir"] *= -1
            boss_bullet_cd -= dt
            if boss_bullet_cd <= 0:
                for angle in [-40, -20, 0, 20, 40]:
                    enemy_bullets.append({"rect": pygame.Rect(boss["rect"].centerx - 10, boss["rect"].bottom, 20, 20), "angle": angle})
                boss_bullet_cd = 1000
        # 掉落物
        spawn_item(mg_items,mgi_img,60000,"mg")
        spawn_item(b_items,bi_img,39000,"b")
        spawn_item(s_items,shield_img,29000,"s")
        spawn_item(h_items,heal_img,64000,"h")
        # 掉落物碰撞
        for lst,act in [(mg_items,lambda:globals().__setitem__('special_count',special_count+1)),
                        (b_items,lambda:(globals().__setitem__('power_mode',True),globals().__setitem__('power_time',10000))),
                        (s_items,lambda:(globals().__setitem__('shield_mode',True),globals().__setitem__('shield_time',6000))),
                        (h_items,lambda:globals().__setitem__('player_hp',min(max_hp,player_hp+100)))]:
            for it in lst[:]:
                it.y+=3
                if it.top>HEIGHT: lst.remove(it)
                if it.colliderect(player_rect): act(); lst.remove(it)
        # 子彈碰撞
        for b in bullets[:]:
            if "hit_targets" not in b: b["hit_targets"] = set()
            hit = False
            for en in enemies[:]:
                if b["rect"].colliderect(en["rect"]):
                    target_id = id(en)
                    if target_id not in b["hit_targets"]:
                        en["hp"] -= 30; b["hit_targets"].add(target_id)
                        trect = en["rect"].copy()
                        trect.x -= 100
                        trect.y -= 120
                        if en["hp"] <= 0: explosions.append([trect,0,0]); enemies.remove(en); score += 5
                    hit = True; break
            if boss and b["rect"].colliderect(boss["rect"]):
                target_id = id(boss)
                if target_id not in b["hit_targets"]:
                    boss["hp"] -= 30; b["hit_targets"].add(target_id)
                    if boss["hp"] <= 0 and not boss_dead:
                        boss_dead = True; boss_flash_timer = 1000
                hit = True
            if hit and not b["powered"]: bullets.remove(b)
        # Boss 死亡閃爍
        if boss_dead:
            boss_flash_timer -= dt
            if boss_flash_timer <= 0:
                boss_explosions.append({"rect": boss["rect"].copy(), "frame": 0, "timer": 0})
                boss = None; boss_dead = False; score += 100; screen_shake = 1600
                enemies.clear(); enemy_bullets.clear()
                game_state = "boss_explode"
        # Boss 子彈移動
        for eb in enemy_bullets[:]:
            if isinstance(eb, dict):
                if not boss: enemy_bullets.remove(eb); continue
                dir_vec = pygame.math.Vector2(0, 1).rotate(eb["angle"])
                eb["rect"].x += dir_vec.x * 5; eb["rect"].y += dir_vec.y * 5
                if eb["rect"].top > HEIGHT: enemy_bullets.remove(eb)
                elif eb["rect"].colliderect(player_rect):
                    if not shield_mode: player_hp -= 10; enemy_bullets.remove(eb)
            else:
                eb.y += 5
                if eb.top > HEIGHT: enemy_bullets.remove(eb)
                elif eb.colliderect(player_rect):
                    if not shield_mode: player_hp -= 10; enemy_bullets.remove(eb)
        # 大招碰撞
        for sp in specials:
            for en in enemies[:]:
                if sp["rect"].colliderect(en["rect"]):
                    en["hp"]-=100
                    if en["hp"]<=0: explosions.append([en["rect"].copy(),0,0]); enemies.remove(en); score+=5
        # 狀態更新
        if power_mode: power_time-=dt; power_mode=power_time>0
        if shield_mode: shield_time-=dt; shield_mode=shield_time>0
        # 動畫
        for ex in explosions[:]:
            ex[2]+=1
            if ex[2]>5: ex[2]=0; ex[1]+=1
            if ex[1]>=len(explosion_frames): explosions.remove(ex)
        for sp in specials[:]:
            sp["rect"].y-=special_speed; sp["timer"]+=1
            if sp["timer"]>=5: sp["timer"]=0; sp["frame"]=(sp["frame"]+1)%len(mg_frames)
            if sp["rect"].bottom<0: specials.remove(sp)
        for be in boss_explosions[:]:
            be["timer"] += dt
            if be["timer"] > 166:
                be["timer"] = 0; be["frame"] += 1
                if be["frame"] >= len(boss_explosion_frames):
                    boss_explosions.remove(be)
                    if not boss_explosions: game_state = "victory"
        # 震動
        shake_x = shake_y = 0
        if screen_shake > 0:
            screen_shake -= dt
            shake_x = random.randint(-10, 10); shake_y = random.randint(-10, 10)
        # 玩家血條追趕
        if player_smooth_hp > player_hp: player_smooth_hp -= 1
        elif player_smooth_hp < player_hp: player_smooth_hp += 0.5
        for en in enemies:
            if en["smooth_hp"] > en["hp"]: en["smooth_hp"] -= 5
        if boss:
            if boss["smooth_hp"] > boss["hp"]: boss["smooth_hp"] -= 10
            elif boss["smooth_hp"] < boss["hp"]: boss["smooth_hp"] += 0.5
        # 動態難度
        level = score // 50
        enemy_hp_base = 50 + level * 10
        enemy_spawn_interval = max(500, 1500 - level * 100)

    # === 繪圖 ===
    screen.fill((0,0,0))
    if game_state == "start":
        screen.blit(start_bg_img, (0,0))
        press = render_with_outline("Press any key to start", sub_font, (255,255,255), (0,0,0), 3)
        screen.blit(press, (WIDTH//2 - press.get_width()//2, HEIGHT//2 + 50))

    elif game_state == "playing":
        screen.blit(bg_img, (0+shake_x, bg_y1+shake_y))
        screen.blit(bg_img, (0+shake_x, bg_y2+shake_y))
        bg_y1+=bg_speed; bg_y2+=bg_speed
        if bg_y1>=HEIGHT: bg_y1=-HEIGHT
        if bg_y2>=HEIGHT: bg_y2=-HEIGHT
        draw_playing()

    elif game_state == "boss_explode":
        # === Boss 爆炸震動 ===
        shake_x = shake_y = 0
        if screen_shake > 0:
            screen_shake -= dt
            intensity = max(2, int(screen_shake / 80))  # 逐漸減弱震動
            shake_x = random.randint(-intensity, intensity)
            shake_y = random.randint(-intensity, intensity)
        screen.blit(bg_img, (0 + shake_x, 0 + shake_y))
        for be in boss_explosions[:]:
            be["timer"] += dt
            if be["timer"] > 166:  # 每幀 0.166 秒
                be["timer"] = 0
                be["frame"] += 1
                if be["frame"] >= len(boss_explosion_frames):
                    boss_explosions.remove(be)
                    game_state = "victory"  # 爆炸播放完 → 勝利畫面
        for be in boss_explosions:
            img = pygame.transform.scale(boss_explosion_frames[be["frame"]], (500, 500))
            rect = img.get_rect(center=(be["rect"].centerx, be["rect"].centery + 100))
            screen.blit(img, rect.move(shake_x, shake_y))
    elif game_state == "victory":
        screen.blit(victory_bg_img, (0,0))
        win_text = render_with_outline("Victory!", title_font, (0,255,0), (0,0,0), 4)
        score_text = render_with_outline(f"Score: {score}", sub_font, (255,255,255), (0,0,0), 3)
        press = render_with_outline("Press any key to quit", sub_font, (200,200,200), (0,0,0), 3)
        screen.blit(win_text, (WIDTH//2 - win_text.get_width()//2, HEIGHT//2 - 100))
        screen.blit(score_text, (WIDTH//2 - score_text.get_width()//2, HEIGHT//2))
        screen.blit(press, (WIDTH//2 - press.get_width()//2, HEIGHT//2 + 60))
    
    elif game_state == "defeat":
        screen.blit(defeat_bg_img, (0,0))
        over_text = render_with_outline("Defeat", title_font, (255,0,0), (0,0,0), 2)
        score_text = render_with_outline(f"Score: {score}", sub_font, (255,255,255), (0,0,0), 1)
        press = render_with_outline("Press any key to quit", sub_font, (200,200,200), (0,0,0), 1)
        screen.blit(over_text, (WIDTH//2 - over_text.get_width()//2, HEIGHT//2 - 80))
        screen.blit(score_text, (WIDTH//2 - score_text.get_width()//2, HEIGHT//2))
        screen.blit(press, (WIDTH//2 - press.get_width()//2, HEIGHT//2 + 40))

    if player_hp <= 0 and game_state == "playing":
        game_state = "defeat"
    pygame.display.flip()
pygame.quit(); sys.exit()
